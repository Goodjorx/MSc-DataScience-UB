Parameters are as follows. Observe that there are
matrices and vectors!!!

n=200; p=3; m=400;
G=np.zeros((n,n))
g=np.zeros(n)
A=np.zeros((n,p))
b=np.zeros(p)
C=np.zeros((n,m))
d=np.zeros(m)

print(G.shape)
print(A.shape)
print(C.shape)
print(g.shape)
print(d.shape)
print(b.shape)
