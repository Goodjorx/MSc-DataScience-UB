import numpy as np
from numpy.linalg import norm
from scipy.io import mmread
import scipy.sparse as sp
from scipy.sparse import diags, csr_matrix, csc_matrix
from time import time
import matplotlib.pyplot as plt


def compute_A(G):
    """It computes A as the theory says. A=GD, being G the link matrix and D a diagonal matrix with values 1/n_j or 0, nxn.

    Args:
        G (sparse_matrix): Link matrix.
    
    returns:
        A(sparse_matrix): After computations 
    """
    d = np.sum(G, axis=0) # n_j = sum(g_ij)
    D = sp.diags(np.squeeze(np.asarray(np.divide(1, d, where=d!=0))))
    A = np.dot(G, D)
    
    return A

def PR_storing(A, m=0.15, tol=1e-6):
    """Computes the PageRank algorithm, which is a way of ranking the importance of nodes in a graph based on the structure of the graph.

    Args:
        A (sparse_matrix): The matrix storing info of network
        m (float, optional): Dampling factor. Defaults to 0.15.
        tol (_type_, optional): Tolerance to stop computing. Defaults to 1e-12.

    Returns:
        sparse_matrix: The PR vector.
    """
    n = A.shape[0]
    # e is n x 1.
    e = np.ones((n))
    # z is m/n if A!=0 or 1/n.
    d = np.sum(A, axis=0)
    z = np.where(d!=0, m/n, 1/n)
    # Scoring intializing
    xk = np.ones((n))
    xk1 = np.ones(n) / n

    while np.linalg.norm(xk1 - xk, np.inf) > tol:
        # Update values until ||xk1 - xk|| < tol.
        xk = xk1
        # x_k1 is (1-m)Axk + ez^t*xk 
        xk1 = (1 - m) * A.dot(xk) + e * z.dot(xk)
    
    return xk/np.sum(xk)

def compute_L(rows, cols):
    """Compute the webpages with link with subject to gij=0 if i not in L. 

    Args:
        rows (matrix): Non zero values
        cols (matrix): Non zero values

    Returns:
        idxs: Indices of valid values.
    """
    idxs = defaultdict(list)
    for i in range(len(cols)):
        idxs[cols[i]].append(rows[i])

    return idxs

def PR_without_storing(A, m=0.15, tol=1e-6):
    """
    Implements PageRank algorithm, but instead of storing the matrix A in memory, it processes the non-zero elements of A one by one to compute the PageRank vector.

    Args:
        A (sparse_matrix): The matrix storing info of network.
        m (float, optional): Dampling factor. Defaults to 0.15.
        tol (int, optional): Tolerance to stop computing. Defaults to 1e-12.

    Returns:
        sparse_matrix: The PR vector.
    """
    n = A.shape[0]
    idxs = compute_L(A.nonzero()[0], A.nonzero()[1])    
    # Initialize values.
    x = np.zeros(n)
    xc = np.ones(n) / n
    # Iterate with stopping criteria.
    while norm(x - xc, np.inf) > tol:
        # Code by Arturo. Implementation of Mx.
        xc=x
        x=np.zeros(n)
        for j in range (0,n):
            if j in idxs:
                if len(idxs[j]) != 0:
                    x[idxs[j]] = x[idxs[j]] + xc[j] / len(idxs[j])
                else:
                    x += xc[j] / n
            else:
                x += xc[j]/n
        x = (1-m)*x + m/n

    return x / np.sum(x)


if __name__ == '__main__':
    # Plots
    pr_storing_res = []
    pr_nostoring_res = []
    difference_res = []
    m_values = [0.05, 0.15, 0.3, 0.5, 0.75, 0.9]
    # Respect to sampling factor
    for m in m_values:
        # Read matrix
        G = mmread("p2p-Gnutella30.mtx")
        A = csr_matrix(compute_A(G)) # Sparse matrix.
        ### STORING
        # Compute times
        start_storing = time()
        pr_storing = PR_storing(A, m, tol=1e-8)
        end_storing = time()
        storing_time = end_storing - start_storing
        print(f"PR vector, with m={m} is: {pr_storing}\n")
        print(f"Execution time: {storing_time} seconds")
        ### NO STORING
        start_nostoring = time()
        pr_nostoring = PR_without_storing(A, m, tol=1e-6)
        end_nostoring = time()
        difference = norm(pr_storing - pr_nostoring, 2)
        no_storing_time = end_nostoring - start_nostoring

        print(f"PR vector, with m={m} is: {pr_nostoring}\n")
        print(f"Execution time: {no_storing_time} seconds")
        print(f"Norm between results: {difference}")
        # SAVE RESULTS
        pr_storing_res.append(storing_time)
        pr_nostoring_res.append(no_storing_time)
        difference_res.append(difference)
    # PLOTS
    fig_results, axs_results = plt.subplots(3,1,figsize=(12,18))

    axs_results[0].plot(m_values, pr_storing_res)
    axs_results[1].plot(m_values, pr_nostoring_res)      
    axs_results[2].plot(m_values, difference_res)      
    axs_results[0].set_title('Time for storing algorithm')          
    axs_results[1].set_title('Time for non-storing algorithm')          
    axs_results[2].set_title('Precision between both algorithms respect m')          
    axs_results[0].set_xlabel('dampling factor')
    axs_results[1].set_xlabel('dampling factor')
    axs_results[2].set_xlabel('dampling factor')
    axs_results[0].set_ylabel('seconds')
    axs_results[1].set_ylabel('seconds')
    axs_results[2].set_ylabel('norm between PR vectors')

    plt.show()
