# ## C6

# Implement the $LDL^T$ using the .dad matrices 


from utils import *

def M_KKT_withA_LDL(G, C, A, n, m, p, lamb, s):
    row1 = np.concatenate((G, -A, -C), axis=1)
    row2 = np.concatenate((- np.transpose(A), np.zeros((p, p + m))), axis=1)
    row3 = np.concatenate((np.transpose(-C), np.zeros((m, p)), np.diag((-1/lamb)*s)), axis=1)
#     row4 = np.concatenate((np.zeros((m, n+p)), np.diag(s), np.diag(lamb)), axis=1)
    return np.concatenate((row1, row2, row3))
def general_algorithm_LDL(path, maxIter=500, epsilon=10e-16):
    """
    Implements the genralization algo. Given the path with dad files
    and iter number and the Epsilon. 
    path : the folder with dad files
    """
    # Define all the variables needed.
    n = int(np.loadtxt(f'{path}/G.dad')[:,0][-1]) # Read the last column
    p = n//2
    m = 2*n
    # Load vectors. n=1 and m are the columns. 1Dimension.
    g = load_dad(f'{path}/g_.dad', n=1, m=n).ravel() # n 
    d = load_dad(f'{path}/d.dad', n=1, m=m).ravel() # m
    b_v = load_dad(f'{path}/b.dad', n=1, m=p).ravel() # p
    # Load matrices.
    G = load_dad(f'{path}/G.dad', n=n, m=n, sym=True) # nxn
    C = load_dad(f'{path}/C.dad', n=n, m=m) # nx2n | 2n=m
    A = load_dad(f'{path}/A.dad', n=n, m=p) # nxp    
    # Predefined.
    x = np.zeros((n))
    lamb = np.ones((m))
    s = np.ones((m))
    gamma = np.ones((p))
    e = np.ones((m))
    z = np.concatenate((x, gamma, lamb, s)) # N = n+p+m+m

    start = time.time() # Compute time

    # Create M_KKT matrix.
    M = M_KKT_withA_LDL(G, C, A, n, m, p, lamb, s)
    
    for i in range(maxIter):
        ### 1) Predictor Substep
        b = F_z_withA(x, lamb, s, G, g, C, d, A, gamma, b_v) # Rigth hand vector        
        r1 = b[:n]
        r2 = b[n:(n + p)]
        r3 = b[(n+p):(n+p+m)]
        r4 = b[-m:]
        b = np.concatenate(([- r1, -r2, -r3 + (1/lamb)*r4])) # Create rhv for 3x3.
        # Compute LDLs
        L, D, perm = ldl(M) # Save permutation. Now L is not lower triangular.
        P = np.eye(n+p+m)[perm,:]
        y = solve_triangular(L[perm,:], b[perm]) # Solve the system permutated.
        z_ = np.linalg.solve(D, y) # Cannot be solved as a triangular.
        delta = solve_triangular(L.T[:,perm], z_) # Solve for x'. 
        delta = np.dot(P.T, delta) # x = P*x'.
        # Delta has parts from lambda and from s. DIM = n(x) + p(gamma) + m(lamb)
        delta_lambda = delta[(n+p):(n+p+m)]
        delta_s = np.diag(-1/lamb).dot(r4+s*delta_lambda) # Create delta_s.
        delta = np.concatenate([delta, delta_s])
        ### 2) Step-size correction
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 3) Compute parameters
        mu = s.dot(lamb) / m
        mu_ = ((s + alpha * delta_s).dot(lamb + alpha * delta_lambda)) / m
        sigma = (mu_/mu)**3

        ### 4) Corrector substep
        b = np.concatenate((-r1, -r2, -r3 + np.diag(1/lamb).dot(r4 - np.diag(delta_s*delta_lambda).dot(e) + sigma*mu*e))) # Be careful of signs. - in front of eq.
        # Compute LDLs
        L, D, perm = ldl(M) # Save permutation. Now L is not lower triangular.
        y = solve_triangular(L[perm,:], b[perm]) # Solve the system permutated
        z_ = np.linalg.solve(D, y) # Cannot be solved as a triangular.
        delta = solve_triangular(L.T[:,perm], z_)
        delta = np.dot(P.T, delta)

        ### 5) Step-size correction substep
        delta_lambda = delta[(n+p) :(n+p+m)]
        delta_s = np.diag(-1/lamb).dot(r4+s*delta_lambda)
        delta = np.concatenate((delta, delta_s))
        
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 6) Update substep. Define z1. Update Mkkt and b.
        z = z + 0.95 * alpha * delta
        # Stopping criterion. Before updating for time reasons.
        if (np.linalg.norm(- b[:n]) < epsilon) or (np.linalg.norm(- b[n:(n + m)]) < epsilon) or (np.linalg.norm(- b[n+p:(n + p + m)])) < epsilon or (np.abs(mu) < epsilon):
            break
        else:
            x = z[:n]
            gamma = z[(n):(n+p)]
            lamb = z[(n+p):(n+p+m)]
            s = z[-m:]
            M = M_KKT_withA_LDL(G, C, A, n, m, p, lamb, s)

        
    end = time.time()
    # Return different metrics
    total_time = end-start
    iters = i
    min_found = f(x, G, g)
    min_real = f(-g, G, g) # NOT REAL ANYMORE
    k = np.linalg.cond(M)
    
    return total_time, iters, min_found, min_real, k




total_time, iters, min_found, _, k = general_algorithm_LDL(path='optpr1-20221106', maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Condition number of the Mkkt matrix: {k}')




total_time, iters, min_found, _, k = general_algorithm_LDL(path='optpr2', maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Condition number of the Mkkt matrix: {k}')
