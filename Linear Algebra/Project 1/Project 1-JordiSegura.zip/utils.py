#!/usr/bin/env python
# coding: utf-8

# # Projecte 1 NLA - Jordi Segura Pons
# 

# ### Common functions 

import numpy as np
import sys
import time
import pandas as pd
import matplotlib.pyplot as plt
from scipy.linalg import lu_factor, lu_solve, ldl, solve_triangular, cholesky


# Given func
def Newton_step(lamb0, dlamb, s0, ds):
    alp=1
    idx_lamb0=np.array(np.where(dlamb<0))
    if idx_lamb0.size>0:
        alp = min(alp,np.min(-lamb0[idx_lamb0]/dlamb[idx_lamb0]))
    idx_s0=np.array(np.where(ds<0))
    if idx_s0.size>0:
        alp = min(alp,np.min(-s0[idx_s0]/ds[idx_s0]))
    return alp

# My code
def M_KKT(G, C, n, m, lamb, s):
    """
    It creates the M_KKT matrix with A = 0. So ends up being a 3x3. 
    G: A n*n matrix
    C: A n*m matrix
    n,m: dimensions. A priori m>>n. 
    lamb, s: A m dimension matrix.
    Returns:
    Mkkt: A  
    """
    Lambda = np.diag(lamb) # mxm
    S = np.diag(s) # mxm
    row1 = np.concatenate((G, -C, np.zeros((n, m))), axis = 1) # A nx(n+m+m) matrix
    row2 = np.concatenate((np.transpose(-C), np.zeros((m, m)), np.identity(m)), axis = 1) # A nx(n+m+m).
    row3 = np.concatenate((np.zeros((m, n)), S, Lambda), axis = 1) # A mx(n+m+m)
    Mkkt = np.concatenate((row1, row2, row3))
    return Mkkt

def f(x, G, g):
    """
    Creates the function to minimize. 
    x: A n dim. matrix
    G: nxn
    g: A n dim. matrix.
    """
    return 1/2*np.transpose(x).dot(G).dot(x) + np.transpose(g).dot(x)

def F_z(x, lamb, s, G, g, C, d):
    """
    Creates the optimality conditions. Assumes A = 0.
    x: A n dim. matrix
    lamb: A m dim. matrix
    s: A m dim. matrix
    G: nxn
    g: A n dim. matrix.
    C: A nxm matrix
    d: A m dim. matrix
    """
    cond1 = G.dot(x) + g - C.dot(lamb)
    cond2 = s + d - np.transpose(C).dot(x)
    cond3 = s * lamb
    conditions = np.concatenate((cond1, cond2, cond3))
    return conditions

def F_z_withA(x, lamb, s, G, g, C, d, A, gamma, b_v):
    """
    Creates the optimality conditions. Assumes A /= 0.
    x: A n dim. matrix
    lamb: A m dim. matrix
    s: A m dim. matrix
    G: nxn
    g: A n dim. matrix.
    C: A nxm matrix
    d: A m dim. matrix
    A: A nxp matrix
    gamma: A p matrix
    b_v: A p matrix
    
    """
    cond1 = G.dot(x) + g -A.dot(gamma)- C.dot(lamb)
    cond2 = b_v-np.transpose(A).dot(x)
    cond3 = s + d - np.transpose(C).dot(x)
    cond4 = s * lamb
    conditions = np.concatenate((cond1, cond2, cond3, cond4))
    return conditions

def load_dad(path, n=1, m=1, sym=False):
    """
    Load etiher the matrices or the vectors from dad. If n=1 is a vector. 
    If sym=True it copies the values to the symmetric part of the matrix.
    """
    matrix = np.zeros((n,m)) # Creates the matrix/vector
    with open(path, "r") as file:
        dad = file.readlines()
    for line in dad:
        # DAD files starts at 1. row and col needs to be substracted 1.
        if n==1:
            # Vector
            col, val = line.strip().split()
            row = 0 # 1 Dimension
            col = int(col) -1
        else:
            # Matrix
            row, col, val = line.strip().split()
            row = int(row)-1
            col = int(col)-1

        matrix[row, col] = float(val)
        if sym == True:
            matrix[col, row] = float(val)
            
    return matrix

def test_algo(algo, n_iters=500, interval=5):
    # Compute results for different n. 
    results = {}
    for n in range(0,n_iters,interval):
        if n!=0:
            total_time, iters, min_found, min_real, k = algo(n=n, maxIter=100)
            results[n] = {
                'time': total_time,
                'iters': iters,
                'min_found': min_found,
                'min_real': min_real,
                'k': k 
            }
    return results    

# Graphicate results
def report_results(results, title=""):
    df = pd.DataFrame(results).transpose()
    df['error'] = np.abs(df['min_found']-df['min_real'])
    df.drop(['min_found', 'min_real'], axis=1, inplace=True)
    
    fig, axs = plt.subplots(nrows=2, ncols=2, figsize=(15, 12))
    plt.subplots_adjust(hspace=0.5)
    fig.suptitle(f"{title}", fontsize=18, y=0.95)
    
    for ax,col in zip(axs.ravel(), df.columns):
        df[col].plot(title=f'{col} plot', ylabel=col, ax=ax)
    return fig, axs

