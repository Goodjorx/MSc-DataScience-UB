# ## C5

# Write down a program that read data of files and solve with linalg.solve. A $\neq$ 0


from utils import *

def M_KKT_withA(G, C, A, n, m, p, lamb,s):
    row1 = np.concatenate((G, -A, -C, np.zeros((n, m))), axis=1)
    row2 = np.concatenate((- np.transpose(A), np.zeros((p, p + 2*m))), axis=1)
    row3 = np.concatenate((np.transpose(- C), np.zeros((m, p + m)), np.identity(m)), axis=1)
    row4 = np.concatenate((np.zeros((m, n+p)), np.diag(s), np.diag(lamb)), axis=1)
    return np.concatenate((row1, row2, row3, row4))

def general_algorithm(path, maxIter=500, epsilon=10e-16):
    """
    Implements the genralization algo. Given the path with dad files
    and iter number and the Epsilon. 
    path : the folder with dad files
    """
    # Define all the variables needed.
    n = int(np.loadtxt(f'{path}/G.dad')[:,0][-1]) # Read the last column
    p = n//2
    m = 2*n
    # Load vectors. n=1 and m are the columns. 1Dimension.
    g = load_dad(f'{path}/g_.dad', n=1, m=n).ravel() # n 
    d = load_dad(f'{path}/d.dad', n=1, m=m).ravel() # m
    b_v = load_dad(f'{path}/b.dad', n=1, m=p).ravel() # p
    # Load matrices.
    G = load_dad(f'{path}/G.dad', n=n, m=n, sym=True) # nxn
    C = load_dad(f'{path}/C.dad', n=n, m=m) # nx2n | 2n=m
    A = load_dad(f'{path}/A.dad', n=n, m=p) # nxp    
    # Predefined.
    x = np.zeros((n))
    lamb = np.ones((m))
    s = np.ones((m))
    gamma = np.ones((p))
    e = np.ones((m))
    z = np.concatenate((x,gamma, lamb, s)) # N = n+m+m

    start = time.time() # Compute time

    # Create M_KKT matrix.
    M = M_KKT_withA(G, C, A, n, m, p, lamb, s)

    for i in range(maxIter):
        ### 1) Predictor Substep
        b = - F_z_withA(x, lamb, s, G, g, C, d, A, gamma, b_v) # Rigth hand vector        
        delta = np.linalg.solve(M,b) # Solve matrix with linalg. 
        # Delta has parts from lambda and from s. DIM = n(x) + p(gamma) + m(lamb) + m(s)
        delta_lambda = delta[(n+p) :(n+p+m)]
        delta_s = delta[-m:]
        ### 2) Step-size correction
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 3) Compute parameters
        mu = s.dot(lamb) / m
        mu_ = ((s + alpha * delta_s).dot(lamb + alpha * delta_lambda)) / m
        sigma = (mu_/mu)**3

        ### 4) Corrector substep
        b[(n + p + m):] = b[(n + p+ m):] - np.diag(delta_s*delta_lambda).dot(e) + sigma*mu*e
        delta = np.linalg.solve(M, b)

        ### 5) Step-size correction substep
        delta_lambda = delta[(n+p) :(n+p+m)]
        delta_s = delta[-m:]
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 6) Update substep. Define z1. Update Mkkt and b.
        z = z + 0.95 * alpha * delta
        
        # Stopping criterion. Before updating for time reasons.
        if (np.linalg.norm(- b[:n]) < epsilon) or (np.linalg.norm(- b[n:(n + m)]) < epsilon) or (np.linalg.norm(- b[n+p:(n + p + m)])) < epsilon or (np.abs(mu) < epsilon):
            break
        else:
            x = z[:n]
            lamb = z[(n+p):(n+p+m)]
            gamma = z[(n):(n+p)]
            s = z[-m:]
            M = M_KKT_withA(G, C, A, n, m, p, lamb, s)

        
    end = time.time()
    # Return different metrics
    total_time = end-start
    iters = i
    min_found = f(x, G, g)
    min_real = f(-g, G, g) # NOT REAL ANYMORE
    k = np.linalg.cond(M)
    
    return total_time, iters, min_found, min_real, k




total_time, iters, min_found, _, k = general_algorithm(path='optpr1-20221106', maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Condition number of the Mkkt matrix: {k}')




total_time, iters, min_found, _, k = general_algorithm(path='optpr2', maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Condition number of the Mkkt matrix: {k}')
