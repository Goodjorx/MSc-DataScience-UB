
# ## C4

# Write down two programs that solve *Strategy 1* and *Strategy 2*. Report computational times for different values of n and compare with *C3*


from utils import *
# We need to redifine the MKKT for each strategy.
def M_KKT_strategy_1(G, C, lamb, s):
    row1 = np.concatenate((G, - C), axis = 1)
    row2 = np.concatenate((- np.transpose(C), - np.diag(lamb**-1 * s)), axis = 1)
    M = np.concatenate((row1, row2))
    return M

def strategy_1(n, maxIter=500, epsilon=10e-16):
    """
    Implements the strategy 1. Given the arbitrary dimension n and iter number and the Epsilon. 
    """
    #Define all the variables needed.
    m = 2*n
    g = np.random.normal(0, 1, (n)) # Gaussian.
    x = np.zeros((n))
    lamb = np.ones((m))
    s = np.ones((m))
    z = np.concatenate((x, lamb, s)) # N = n+m+m
    G = np.identity(n) # nxn
    C = np.concatenate((G, G), axis = 1) # nx2n | 2n=m
    d = np.full((m), - 10)
    e = np.ones((m))
    
    start = time.time() # Compute time

    # Create M_KKT matrix.
    M = M_KKT_strategy_1(G, C, lamb, s)
    for i in range(maxIter):
        ### 1) Predictor Substep
        b = F_z(x, lamb, s, G, g, C, d) # Rigth hand vector
        # Adapt right hand vector to Strategy 1.
        r1 = b[:n]
        r2 = b[n:(n + m)]
        r3 = b[(n + m):]
        b = np.concatenate(([- r1, -r2 + 1/lamb*r3]))
        # Compute LDL
        L, D, _ = ldl(M)
        y = solve_triangular(L, b, lower=True, unit_diagonal=True)
        delta = solve_triangular(D.dot(np.transpose(L)), y, lower = False)
        delta_s = np.diag(1/lamb).dot(- r3 -s*delta[n:]) # Adapt it. -r3-Sdelta_x.
        delta = np.concatenate((delta, delta_s))
        # Delta has parts from lambda and from s. DIM = n(x) + m(lamb) + m(s)
        delta_lambda = delta[n :(n + m)]
        delta_s = delta[-m:]
        
        ### 2) Step-size correction
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 3) Compute parameters
        mu = s.dot(lamb) / m
        mu_ = ((s + alpha * delta_s).dot(lamb + alpha * delta_lambda)) / m
        sigma = (mu_/mu)**3

        ### 4) Corrector substep
        b = np.concatenate((-r1, -r2 + np.diag(1/lamb).dot(r3 + np.diag(delta_s*delta_lambda).dot(e) - sigma*mu*e))) # Be careful of signs. - in front of eq.
        # Compute LDL
        L, D, _ = ldl(M)
        y = solve_triangular(L, b, lower=True, unit_diagonal=True)
        delta = solve_triangular(D.dot(np.transpose(L)), y, lower = False)
        delta_s = np.diag(1/lamb).dot(-r3 -  np.diag(delta_s*delta_lambda).dot(e) + sigma*mu*e - s*delta[n:])
        delta = np.concatenate((delta, delta_s))
        
        ### 5) Step-size correction substep
        delta_lambda = delta[n :(n + m)]
        delta_s = delta[-m:]
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 6) Update substep. Define z1. Update Mkkt and b.
        z = z + 0.95 * alpha * delta
        
        # Stopping criterion. Before updating for time reasons.
        if (np.linalg.norm(-r1) < epsilon) or (np.linalg.norm(-r2) < epsilon) or (np.abs(mu) < epsilon):
            break
        else:
            x = z[:n]
            lamb = z[n:(n + m)]
            s = z[(n + m):]
            M = M_KKT_strategy_1(G, C, lamb, s)

        
    end = time.time()
    # Return different metrics
    total_time = end-start
    iters = i
    min_found = f(x, G, g)
    min_real = f(-g, G, g) # real test solution is x = -g
    k = np.linalg.cond(M)
    
    return total_time, iters, min_found, min_real, k




total_time, iters, min_found, min_real, k = strategy_1(n=5, maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Real Minimum: {min_real}')
print(f'Condition number of the Mkkt matrix: {k}')




# We need to redifine the MKKT for each strategy.
def M_KKT_strategy_2(G, C, lamb, s):
    # Returns ghat= G+CS^-1*LAMBDA*C^T
    return G + C.dot(np.diag(1/s * lamb)).dot(np.transpose(C))

def strategy_2(n, maxIter=500, epsilon=10e-16):
    """
    Implements the strategy 2. Given the arbitrary dimension n and iter number and the Epsilon. 
    """
    #Define all the variables needed.
    m = 2*n
    g = np.random.normal(0, 1, (n)) # Gaussian.
    x = np.zeros((n))
    lamb = np.ones((m))
    s = np.ones((m))
    z = np.concatenate((x, lamb, s)) # N = n+m+m
    G = np.identity(n) # nxn
    C = np.concatenate((G, G), axis = 1) # nx2n | 2n=m
    d = np.full((m), - 10)
    e = np.ones((m))
    
    start = time.time() # Compute time

    # Create M_KKT matrix.
    Ghat = M_KKT_strategy_2(G, C, lamb, s)

    for i in range(maxIter):
        ### 1) Predictor Substep
        b = F_z(x, lamb, s, G, g, C, d) # Rigth hand vector
        # Adapt right hand vector to Strategy 2.
        r1 = b[:n]
        r2 = b[n:(n + m)]
        r3 = b[(n + m):]
        rhat = -C.dot(np.diag(1/s)).dot((lamb*r2-r3)) #-CS^-1(lambda*r2 -r3)
        b = -r1 -rhat
        # Compute Cholesky
        Cholesky = cholesky(Ghat, lower=True)
        y = solve_triangular(Cholesky, b, lower=True)
        # Compute delta x,lambda,s:
        delta_x = solve_triangular(np.transpose(Cholesky), y)
        delta_l = np.diag(1/s).dot((lamb*r2- r3)) - np.diag(1/s).dot(np.diag(lamb).dot(np.transpose(C)).dot(delta_x))
        delta_s_ = -r2 + np.transpose(C).dot(delta_x)
        delta = np.concatenate((delta_x,delta_l,delta_s_))
        
        # Delta has parts from lambda and from s. DIM = n(x) + m(lamb) + m(s)
        delta_lambda = delta[n :(n + m)]
        delta_s = delta[-m:]
        
        ### 2) Step-size correction
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 3) Compute parameters
        mu = s.dot(lamb) / m
        mu_ = ((s + alpha * delta_s).dot(lamb + alpha * delta_lambda)) / m
        sigma = (mu_/mu)**3

        ### 4) Corrector substep
        rhat_corr = -C.dot(np.diag(1/s)).dot(-r3 +lamb*r2 -np.diag(delta_s*delta_lambda).dot(e) + sigma*mu*e)
        b = -r1 -rhat_corr
        # Compute Cholesky
        y = solve_triangular(Cholesky, b, lower=True)
        # Compute delta x,lambda,s:
        delta_x = solve_triangular(np.transpose(Cholesky), y)
        delta_l = np.diag(1/s).dot((lamb*r2 -r3 -np.diag(delta_s*delta_lambda).dot(e) + sigma*mu*e)) - np.diag(1/s).dot(np.diag(lamb)).dot(np.transpose(C)).dot(delta_x)
        delta_s_ = -r2 + np.transpose(C).dot(delta_x)
        delta = np.concatenate((delta_x,delta_l,delta_s_))  
        
        ### 5) Step-size correction substep
        delta_lambda = delta[n :(n + m)]
        delta_s = delta[-m:]
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 6) Update substep. Define z1. Update Mkkt and b.
        z = z + 0.95 * alpha * delta
        
        # Stopping criterion. Before updating for time reasons.
        if (np.linalg.norm(-r1) < epsilon) or (np.linalg.norm(-r2) < epsilon) or (np.abs(mu) < epsilon):
            break
        else:
            x = z[:n]
            lamb = z[n:(n + m)]
            s = z[(n + m):]
            Ghat = M_KKT_strategy_2(G, C, lamb, s)

        
    end = time.time()
    # Return different metrics
    total_time = end-start
    iters = i
    min_found = f(x, G, g)
    min_real = f(-g, G, g) # real test solution is x = -g
    k = np.linalg.cond(Ghat)
    
    return total_time, iters, min_found, min_real, k




total_time, iters, min_found, min_real, k = strategy_2(n=50, maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Real Minimum: {min_real}')
print(f'Condition number of the Mkkt matrix: {k}')




strategy1_results = test_algo(strategy_1)
strategy2_results = test_algo(strategy_2)




strat1_fig,_= report_results(strategy1_results, title='Strategy 1 report. Solving with LDL')
strat2_fig,_ = report_results(strategy2_results, title='Strategy 2 report. Solving with Cholesky')
strat1_fig.savefig('strategy1_report.png')
strat2_fig.savefig('strategy2_report.png')

