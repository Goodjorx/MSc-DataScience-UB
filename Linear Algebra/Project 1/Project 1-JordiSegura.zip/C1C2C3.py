# ## C1-C2-C3

# C1: Write down a routine function that implements the step-size substep.\
# C2: Write down a program that, for a given n, implements the full algorithm for the test
# problem. Use the numpy.linalg.solve function to solve the KKT linear systems of the predictor
# and corrector substeps directly.\
# C3: Write a modification of the previous program C2 to report the computation time of the
# solution of the test problem for diferent dimensions n.\
# => \
# *Write down a program that implements the full algorithm for the test problem reporting the computation time for different dimensions*

from utils import *


def main(n, maxIter=500, epsilon=10**-16):
    """
    Implements the whole algo. Given the arbitrary dimension n and iter number and the Epsilon. 
    """
    #Define all the variables needed.
    m = 2*n
    g = np.random.normal(0, 1, (n)) # Gaussian.
    x = np.zeros((n))
    lamb = np.ones((m))
    s = np.ones((m))
    z = np.concatenate((x, lamb, s)) # N = n+m+m
    G = np.identity(n) # nxn
    C = np.concatenate((G, G), axis = 1) # nx2n | 2n=m
    d = np.full((m), - 10)
    e = np.ones((m))
    
    start = time.time() # Compute time

    # Create M_KKT matrix.
    M = M_KKT(G, C, n, m, lamb, s)

    for i in range(maxIter):
        ### 1) Predictor Substep
        b = - F_z(x, lamb, s, G, g, C, d) # Rigth hand vector        
        delta = np.linalg.solve(M,b) # Solve matrix with linalg. 
        # Delta has parts from lambda and from s. DIM = n(x) + m(lamb) + m(s)
        delta_lambda = delta[n :(n + m)]
        delta_s = delta[-m:]
        
        ### 2) Step-size correction
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 3) Compute parameters
        mu = s.dot(lamb) / m
        mu_ = ((s + alpha * delta_s).dot(lamb + alpha * delta_lambda)) / m
        sigma = (mu_/mu)**3

        ### 4) Corrector substep
        b[(n + m):] = b[(n + m):] - np.diag(delta_s*delta_lambda).dot(e) + sigma*mu*e
        delta = np.linalg.solve(M, b)

        ### 5) Step-size correction substep
        delta_lambda = delta[n :(n + m)]
        delta_s = delta[-m:]
        alpha = Newton_step(lamb, delta_lambda, s, delta_s)

        ### 6) Update substep. Define z1. Update Mkkt and b.
        z = z + 0.95 * alpha * delta
        
        # Stopping criterion. Before updating for time reasons.
        if (np.linalg.norm(- b[:n]) < epsilon) or (np.linalg.norm(- b[n:(n + m)]) < epsilon) or (np.abs(mu) < epsilon):
            break
        else:
            x = z[:n]
            lamb = z[n:(n + m)]
            s = z[(n + m):]
            M = M_KKT(G, C, n, m, lamb, s)

        
    end = time.time()
    # Return different metrics
    total_time = end-start
    iters = i
    min_found = f(x, G, g)
    min_real = f(-g, G, g) # real test solution is x = -g
    k = np.linalg.cond(M)
    
    return total_time, iters, min_found, min_real, k

total_time, iters, min_found, min_real, k = main(n=500, maxIter=100)
print(f'Time: {total_time} seconds')
print(f'Number of iterations: {iters}')
print(f'Minimum that was found: {min_found}')
print(f'Real Minimum: {min_real}')
print(f'Condition number of the Mkkt matrix: {k}')

solve_results = test_algo(main)

c3_fig, _ = report_results(solve_results, title='Report for C3. Solving with linalg.solve')
c3_fig.savefig('c3_report.png')