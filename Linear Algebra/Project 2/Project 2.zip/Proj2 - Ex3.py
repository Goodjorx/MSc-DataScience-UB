#!/usr/bin/env python
# coding: utf-8

# In[23]:


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def var_acc(S):
    # Returns the portion of the total variance in the component. s_i^2/
    return S**2 / np.sum(S**2)

def covariance_matrix(matrix):
    # Returns the matrix minus its mean.
    return matrix - np.mean(matrix, axis=0)

def correlation_matrix(matrix):
    # Returns the matrix minus its mean divided by the standard deviation.
    matrix = matrix - np.mean(matrix, axis=0)
    std = np.std(matrix, axis=0)
    return matrix / std


if __name__ == '__main__':
    
    print(f'{50*"*"}')
    print('Example.dat PCA')
    print(f'{50*"*"}')
    
    # Read data
    data = pd.read_csv("example.dat", sep=" ", header=None)
    dades = np.asarray(data)
    n = dades.shape[0]
    # Execute PCA
    ### Covariance 
    print(f'{20*"*"}')
    print('Using COVARIANCE')
    print(f'{20*"*"}')

    X = covariance_matrix(dades)
    Y = np.dot((1 / np.sqrt(n - 1)), X.T)
    U, S, Vt = np.linalg.svd(Y, full_matrices=False)
    
    print("Portion of the total variance accumulated in each of the principal components:")
    print(var_acc(S))
    print("\nStandard deviation of each of the principal components:")
    print(np.std(Vt.T,axis=1))
    print("\nDataset in the PCA coordinates:")
    print(Vt.dot(X).T)

    ### Correlation 
    print(f'{20*"*"}')
    print('Using CORRELATION')
    print(f'{20*"*"}')
    
    X = correlation_matrix(dades)
    Y = np.dot((1 / np.sqrt(n - 1)), X.T)
    U, S, Vt = np.linalg.svd(Y, full_matrices=False)
    
    print("Portion of the total variance accumulated in each of the principal components:")
    print(var_acc(S))
    print("\nStandard deviation of each of the principal components:")
    print(np.std(Vt.T,axis=1))
    print("\nDataset in the PCA coordinates:")
    print(Vt.dot(X).T)
    
    # Scree plot
    plt.plot(range(1, 5), S, 'o-')
    plt.axhline(y=1, color='r', linestyle='-')
    plt.xlabel('PCA components')
    plt.ylabel('Variance hold')
#     plt.xticks([i for i in range(1,PCA_idxs+1)])
    plt.show()
    #####################################
    
    # Code for RCsGoff.csv
    print('\n\n')
    print(f'{50*"*"}')
    print('RCsGoff.csv PCA w/ COVARIANCE')
    print(f'{50*"*"}')
    # Read data
    data = pd.read_csv('RCsGoff.csv') 
    data.drop('gene', axis=1, inplace=True) #58581x20 
    dades = data.values.T # 20x58581
    n = dades.shape[0]
    # Perform PCA
    X = covariance_matrix(dades)
    Y = np.dot((1 / np.sqrt(n - 1)), X.T)
    U, S, Vt = np.linalg.svd(Y,full_matrices=False)
    PCA_idxs = Vt.shape[0]
    # Create the dataframe
    ### New coordinates are V^tX
    PCA_df = pd.DataFrame(data=Vt.dot(X)[:,:PCA_idxs],index=data.columns,columns = [f'PCA{i+1}' for i in range(PCA_idxs)])
    PCA_df.index.name = 'Sample'
    PCA_df['Variance'] = var_acc(S)
    print(PCA_df)
    # Scree plot
    plt.plot(range(1, PCA_idxs+1), S, 'o-')
    plt.axhline(y=1, color='r', linestyle='-')
    plt.xlabel('PCA components')
    plt.ylabel('Variance hold')
    plt.xticks([i for i in range(1,PCA_idxs+1)])
    plt.show()
    
    plt.scatter(PCA_df.iloc[:,0], PCA_df.iloc[:,1])
    plt.xlabel(f'PC1 with {PCA_df.iloc[0,-1]*100} % variance')
    plt.ylabel(f'PC2 with {PCA_df.iloc[1,-1]*100} % variance')    
    plt.show()


# In[3]:


PCA_df


# In[ ]:




