#!/usr/bin/env python
# coding: utf-8

# ## 2.2 Compressed graphic images

# In[2]:


import imageio
import matplotlib.pyplot as plt
import numpy as np
import warnings
# Deactivate warnings
warnings.filterwarnings("ignore")

im = imageio.imread('bari.jpg')
Image = im[:,:,1]
im2 = imageio.imread('arabic.jpg')
Image2 = im2[:,:,1]

def funct2(matrix, name):
    U, sigma, V = np.linalg.svd(matrix)
    for i in [1, 5, 20, 100, 500]:
        A = np.matrix(U[:, :i]) * np.diag(sigma[:i]) * np.matrix(V[:i, :]) # Compute SVD
        #Compute the relative error error
        relative_error = sigma[i] / sigma[0]
        
        #Create the name with Frob norm captured
        frobenius = np.linalg.norm(A)/np.linalg.norm(matrix)
        path = f'{name}_{round(frobenius, 4)}.jpg'
        #Save image
        imageio.imwrite(path, np.clip(A, 0, 255).astype(np.uint8))
    
        print(f"Percentage of Frobenius norm captured in the compression: {frobenius}")
        print(f"Relative error for k={i}: {round((1-relative_error)*100,2)}")
        print(f"Image name: {path}\n")

    return True

if __name__ == '__main__':
    
    # IMAGE
    print(f'{50*"*"}')
    print('Picture of Bari')
    print(f'{50*"*"}')
    funct2(Image, "Bari")
    # TEXT
    print(f'{50*"*"}')
    print('Picture of Arabic Alphabet')
    print(f'{50*"*"}')
    funct2(Image2, "Arabic")


# In[ ]:




