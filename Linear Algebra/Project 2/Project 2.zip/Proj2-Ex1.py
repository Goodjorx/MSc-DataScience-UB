#!/usr/bin/env python
# coding: utf-8

# In[5]:


import numpy as np
import pandas as pd
from scipy.linalg import solve_triangular, qr
import matplotlib.pyplot as plt
import time 

def LS_SVD(A, b):
    # Compute the singular value decomposition of A
    U, s, V = np.linalg.svd(A, full_matrices=False)
    # Compute the pseudo-inverse and multiplies by b
    return V.T.dot(np.linalg.inv(np.diag(s))).dot(U.T).dot(b)

def LS_QR(A, b):
    # Compute the QR factorization of A. Rank-deficient matrices!
    rank = np.linalg.matrix_rank(A)
    q, r, p = qr(A, mode='economic', pivoting=True)
    r = r[:rank, :rank]
    y = np.dot(q.T, b)[:rank]
    x = np.linalg.solve(r, y)
    # Treat rank-deficient
    a = np.eye(A.shape[1])[:, p].T
    b_ = np.concatenate((x, np.zeros((A.shape[1] - rank))))
    # Solve matrix
    x_qr = np.linalg.solve(a, b_)

    return x_qr
    
if __name__ == '__main__':

    print(f"{50*'*'}")
    print("Datafile 1")
    print(f"{50*'*'}")
    
    # Declare variables for matrix in txt 1.
    matrix = []
    degrees = [1, 2, 5, 25]
    f = open("datafile.txt", "r")
    lines = f.readlines()
    for line in lines:
        matrix.append(np.fromstring(line, sep=' '))
    matrix = np.asarray(matrix)
    n = matrix.shape[0]
    # Build the full matrix
    full_A = np.zeros((n, np.max(degrees) + 1)) 
    for i in range(n):
        full_A[i, :] = [matrix[i, 0]**d for d in range(np.max(degrees) + 1)]
    
    b = matrix[:, 1]
    # Declare space
    x = np.linspace(np.min(matrix), np.max(10), 100)
    # Solution per degree.
    for m in (degrees):
        print(f"Degree ===> {m}")
        A = full_A[:,:m + 1]
        # Compute QR
        qr_start = time.time()
        x_qr = LS_QR(A, b)
        qr_stop = time.time()
        # Compute SVD 
        svd_start = time.time()
        x_svd = LS_SVD(A, b)
        svd_stop = time.time()
        # Solutions and comparisons:
        print(" SVD:")
        print("  LS Solution = ", x_svd)
        print("  Norm = ", np.linalg.norm(x_svd))
        print("  Time = ", qr_stop - qr_start)
        print('')
        print(" QR:")
        print("  LS Solution = ", x_qr)
        print("  Norm = ", np.linalg.norm(x_qr))
        print("  Time = ", svd_stop - svd_start)
        print("  \n")
        
        # Plots for solutions
        y = sum(x_svd[i] * x**i for i in range(m + 1))
        y2 = sum(x_qr[i] * x**i for i in range(m + 1))
        plt.scatter(matrix[:, 0],matrix[:, 1],s = 3)
        plt.plot(x, y, label = str(m) + ' degree SVD') # SVD
        plt.plot(x, y2, label = str(m) + ' degree QR') # QR
        plt.legend()
        plt.show()

    ### DATAFILE 2    
    print(f"{50*'*'}")
    print("Datafile 2")
    print(f"{50*'*'}")

    matrix = pd.read_csv("datafile2.csv",header=None)
    A = matrix.iloc[:,:-1].values
    b = matrix.iloc[:,-1].values

    # Compute QR
    qr_start = time.time()
    x_qr_2 = LS_QR(A,b)
    qr_stop = time.time()
    # Compute SVD 
    svd_start = time.time()
    x_svd_2 = LS_SVD(A,b)
    svd_stop = time.time()
    # Solutions and comparisons
    print(" SVD:")
    print("  LS Solution = ", x_svd_2)
    print("  Norm = ", np.linalg.norm(x_svd_2))
    print("  Time = ", qr_stop - qr_start)
    print('')
    print(" QR:")
    print("  LS Solution = ", x_qr_2)
    print("  Norm = ", np.linalg.norm(x_qr_2))
    print("  Time = ", svd_stop - svd_start)
    print("  \n")


# In[ ]:




